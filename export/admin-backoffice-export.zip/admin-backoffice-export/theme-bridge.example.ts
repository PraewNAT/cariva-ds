/**
 * Example: merge Cariva DS semantic tokens into admin-dashboard theme schema.
 *
 * Usage in admin-dashboard (after copying tokens.ts):
 *   import { buildAdminPalettePatch } from '@/ds-bridge/theme-bridge.example';
 *   import existingTheme from '@/muiTheme/muiTheme';
 *   import { createTheme } from '@mui/material/styles';
 *
 *   const theme = createTheme(existingTheme, buildAdminPalettePatch({ useProductBrand: true }));
 *
 * Do NOT replace src/muiTheme/muiTheme.ts wholesale — merge patches only (Option A bridge).
 */

import type { ThemeOptions } from '@mui/material/styles';
import { colors, adminProductBrand, defaultProductStyle, productStyle } from './tokens';

type BuildOptions = {
  /** Round 1: true = keep admin #0075EA; false = Core DS #2563eb */
  useProductBrand?: boolean;
};

function hexToRgb(hex: string): [number, number, number] {
  const h = hex.replace('#', '');
  return [
    parseInt(h.slice(0, 2), 16),
    parseInt(h.slice(2, 4), 16),
    parseInt(h.slice(4, 6), 16),
  ];
}

function primaryStatesFrom(main: string) {
  const [r, g, b] = hexToRgb(main);
  return {
    hover: `rgba(${r}, ${g}, ${b}, 0.04)`,
    selected: `rgba(${r}, ${g}, ${b}, 0.08)`,
    focus: `rgba(${r}, ${g}, ${b}, 0.12)`,
    focusVisible: `rgba(${r}, ${g}, ${b}, 0.30)`,
  };
}

export function buildAdminPalettePatch(options: BuildOptions = {}): ThemeOptions {
  const useProductBrand = options.useProductBrand ?? true;
  const primaryMain = useProductBrand
    ? adminProductBrand.primary.main
    : colors.brand.primary.onSurface.default;
  const primaryDark = useProductBrand
    ? adminProductBrand.primary.dark
    : colors.brand.primary.onSurface.hover;
  const primaryLight = useProductBrand
    ? adminProductBrand.primary.light
    : colors.brand.primary.border.strong;

  const profile = productStyle[defaultProductStyle];

  return {
    palette: {
      primary: {
        main: primaryMain,
        dark: primaryDark,
        light: primaryLight,
        contrastText: colors.content.inverse,
      },
      warning: {
        main: colors.status.warning.onSurface.default,
        contrastText: colors.content.primary,
      },
      error: {
        main: colors.status.error.onSurface.default,
      },
      success: {
        main: colors.status.success.onSurface.default,
      },
      divider: colors.border.default,
      primaryStates: primaryStatesFrom(primaryMain),
      backgroundColor: {
        main: useProductBrand ? adminProductBrand.background.page : colors.bg.subtle,
        white: useProductBrand ? adminProductBrand.background.surface : colors.bg.white,
        overlay: colors.overlay.backdrop,
      },
      textColor: {
        black: {
          primary: colors.content.primary,
          secondary: colors.content.secondary,
          tertiary: colors.content.placeholder,
          disabled: colors.content.disabled,
        },
        white: {
          primary: colors.content.inverse,
          secondary: 'rgba(255, 255, 255, 0.87)',
          tertiary: 'rgba(255, 255, 255, 0.60)',
          disabled: 'rgba(255, 255, 255, 0.38)',
        },
      },
      icon: colors.content.secondary,
      outlinedBorder: {
        color: colors.border.default,
        hoverColor: colors.border.strong,
        width: '1px',
      },
    },
    // Shape hints for patch-guide — actual overrides stay in muiTheme.ts styleOverrides
    shape: {
      borderRadius: profile.inputSm,
    },
  };
}

/** Semantic-only patch (status, borders, surfaces) — safe without brand migration */
export function buildSemanticOnlyPatch(): ThemeOptions {
  return buildAdminPalettePatch({ useProductBrand: true });
}
