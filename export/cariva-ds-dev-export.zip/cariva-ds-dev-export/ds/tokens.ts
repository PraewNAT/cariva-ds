/**
 * Cariva Design System — Tokens
 * ⚠️  colors section is AUTO-GENERATED from tokens.json
 * DO NOT EDIT colors manually — run: npm run tokens:generate
 *
 * Source: tokens.json (synced from Figma via token-sync skill)
 * Figma file: https://www.figma.com/design/XgxprkSY5mGbzIIwlmscCt/Cariva-Core-Design-System
 */

export const colors = {
  brand: {
    primary: {
      onSurface: {
        default: '#1789fa',
        hover: '#0f70e6',
        pressed: '#135aba',
        subtle: '#eef9ff',
        muted: '#d8f0ff',
      },
      content: {
        default: '#1789fa',
        strong: '#0f70e6',
      },
      border: {
        default: '#8bd8ff',
        strong: '#2da4ff',
      },
    },
    secondary: {
      onSurface: {
        default: '#0f766e',
        hover: '#115e59',
        pressed: '#134e4a',
        subtle: '#f0fdfa',
        muted: '#ccfbf1',
      },
      content: {
        default: '#0d9488',
        strong: '#0f766e',
      },
      border: {
        default: '#5eead4',
        strong: '#14b8a6',
      },
    },
    decorative: {
      gradient: {
        from: '#192450',
        via: '#1789fa',
        to: '#55ebff',
      },
    },
  },
  neutral: {
    onSurface: {
      default: '#e2e8f0',
      hover: '#cbd5e1',
      pressed: '#94a3b8',
      subtle: '#f8fafc',
      muted: '#f1f5f9',
    },
    content: {
      default: '#0f172a',
      strong: '#0f172a',
    },
    border: {
      default: '#cbd5e1',
      strong: '#94a3b8',
    },
  },
  content: {
    primary: '#0f172a',
    secondary: '#64748b',
    placeholder: '#64748b',
    disabled: '#94a3b8',
    inverse: '#ffffff',
    link: {
      default: '#2563eb',
      hover: '#1d4ed8',
      pressed: '#1e40af',
      disabled: '#475569',
    },
    onBrand: '#ffffff',
  },
  bg: {
    white: '#ffffff',
    subtle: '#f1f5f9',
    inverse: '#0f172a',
    solid: '#e2e8f0',
  },
  onSurface: {
    default: '#ffffff',
    subtle: '#f8fafc',
    elevated: '#ffffff',
    sunken: '#f1f5f9',
    overlay: '#ffffff',
    action: {
      hover: '#f1f5f9',
      pressed: '#e2e8f0',
      selected: '#eef9ff',
      disabled: '#f1f5f9',
      selectedStrong: '#d8f0ff',
    },
    invert: '#0f172a',
    sunkenStrong: '#cbd5e1',
  },
  border: {
    default: '#cbd5e1',
    strong: '#94a3b8',
    disabled: '#e2e8f0',
    system: '#2563eb',
    error: '#dc2626',
  },
  status: {
    success: {
      onSurface: {
        default: '#047857',
        hover: '#065f46',
        pressed: '#064e3b',
        muted: '#d1fae5',
        subtle: '#ecfdf5',
      },
      content: {
        default: '#047857',
        strong: '#065f46',
      },
      border: {
        default: '#d1fae5',
        strong: '#10b981',
      },
    },
    active: {
      onSurface: {
        default: '#4ade80',
        muted: '#dcfce7',
      },
      content: {
        default: '#22c55e',
      },
    },
    warning: {
      onSurface: {
        default: '#d97706',
        hover: '#b45309',
        pressed: '#92400e',
        subtle: '#fffbeb',
        muted: '#fef3c7',
      },
      content: {
        default: '#d97706',
        strong: '#b45309',
      },
      border: {
        default: '#fef3c7',
        strong: '#f59e0b',
      },
    },
    error: {
      onSurface: {
        default: '#dc2626',
        hover: '#b91c1c',
        pressed: '#991b1b',
        subtle: '#fef2f2',
        muted: '#fee2e2',
      },
      content: {
        default: '#dc2626',
        strong: '#b91c1c',
      },
      border: {
        default: '#fee2e2',
        strong: '#ef4444',
      },
    },
    info: {
      onSurface: {
        default: '#0284c7',
        hover: '#0369a1',
        pressed: '#075985',
        subtle: '#f0f9ff',
        muted: '#e0f2fe',
      },
      content: {
        default: '#0284c7',
        strong: '#0369a1',
      },
      border: {
        default: '#e0f2fe',
        strong: '#0ea5e9',
      },
    },
  },
  overlay: {
    backdrop: '#00000066',
  },
  accent: {
    red: {
      A02: '#fee2e2',
      A03: '#fca5a5',
      A04: '#ef4444',
      A05: '#b91c1c',
      A06: '#7f1d1d',
      A01: '#fef2f2',
    },
    orange: {
      A02: '#ffedd5',
      A03: '#fdba74',
      A04: '#f97316',
      A05: '#c2410c',
      A06: '#7c2d12',
      A01: '#fff7ed',
    },
    amber: {
      A02: '#fef3c7',
      A03: '#fcd34d',
      A04: '#f59e0b',
      A05: '#b45309',
      A06: '#78350f',
      A01: '#fffbeb',
    },
    yellow: {
      A02: '#fef9c3',
      A03: '#fde047',
      A04: '#eab308',
      A05: '#a16207',
      A06: '#713f12',
      A01: '#fefce8',
    },
    lime: {
      A02: '#ecfccb',
      A03: '#bef264',
      A04: '#84cc16',
      A05: '#4d7c0f',
      A06: '#365314',
      A01: '#f7fee7',
    },
    green: {
      A02: '#dcfce7',
      A03: '#86efac',
      A04: '#22c55e',
      A05: '#15803d',
      A06: '#14532d',
      A01: '#f0fdf4',
    },
    emerald: {
      A02: '#d1fae5',
      A03: '#6ee7b7',
      A04: '#10b981',
      A05: '#047857',
      A06: '#064e3b',
      A01: '#ecfdf5',
    },
    teal: {
      A02: '#ccfbf1',
      A03: '#5eead4',
      A04: '#14b8a6',
      A05: '#0f766e',
      A06: '#134e4a',
      A01: '#f0fdfa',
    },
    cyan: {
      A02: '#cffafe',
      A03: '#67e8f9',
      A04: '#06b6d4',
      A05: '#0e7490',
      A06: '#164e63',
      A01: '#ecfeff',
    },
    sky: {
      A02: '#e0f2fe',
      A03: '#7dd3fc',
      A04: '#0ea5e9',
      A05: '#0369a1',
      A06: '#0c4a6e',
      A01: '#f0f9ff',
    },
    blue: {
      A02: '#dbeafe',
      A03: '#93c5fd',
      A04: '#3b82f6',
      A05: '#1d4ed8',
      A06: '#1e3a8a',
      A01: '#eff6ff',
    },
    indigo: {
      A02: '#e0e7ff',
      A03: '#a5b4fc',
      A04: '#6366f1',
      A05: '#4338ca',
      A06: '#312e81',
      A01: '#eef2ff',
    },
    violet: {
      A02: '#ede9fe',
      A03: '#c4b5fd',
      A04: '#8b5cf6',
      A05: '#6d28d9',
      A06: '#4c1d95',
      A01: '#f5f3ff',
    },
    purple: {
      A02: '#f3e8ff',
      A03: '#d8b4fe',
      A04: '#a855f7',
      A05: '#7e22ce',
      A06: '#581c87',
      A01: '#faf5ff',
    },
    pink: {
      A02: '#fce7f3',
      A03: '#f9a8d4',
      A04: '#ec4899',
      A05: '#be185d',
      A06: '#831843',
      A01: '#fdf2f8',
    },
  },
} as const;

export const spacing = {
  none:  0,
  '2xs': 2,
  xs:    4,
  sm:    8,
  md:    12,
  lg:    16,
  xl:    24,
  '2xl': 28,
  '3xl': 32,
  '4xl': 40,
} as const;

export const radius = {
  none:  0,
  '2':   2,
  '4':   4,
  '8':   8,
  '12':  12,
  '16':  16,
  '24':  24,
  '32':  32,
  full:  9999,
} as const;

/**
 * Product Style — theme-aware radius tokens.
 * Mirrors Figma's "Product Style" collection (modes: cariva app / back office).
 */
export const productStyle = {
  carivaApp: {
    interactive: radius.full,
    inputSm:     radius.full,
    inputMd:     radius.full,
    containerSm: radius['12'],
    containerMd: radius['16'],
    fontFamily: {
      // Aktiv Grotesk Thai is an Adobe Font — it requires an active Adobe Fonts
      // subscription and the kit link from code/fonts.ts to be loaded in the
      // document <head>. Fall back to the self-hosted fonts below if the kit
      // fails to load (offline, expired subscription, etc).
      //
      // Google Sans is NOT in the kit (checked against tfw1cme on 2026-09-16).
      // It is self-hosted from @fontsource/google-sans (OFL-1.1) by
      // code/fonts.ts, so `prose` renders without any subscription.
      //
      // Each Adobe family is listed twice on purpose. The first spelling is the
      // typeface name as installed by Creative Cloud desktop; the second is the
      // CSS family the web kit actually declares (`aktiv-grotesk-thai`). CSS
      // treats those as different families, so a stack with only the spaced name
      // silently renders the desktop font on designers' machines and falls back
      // to IBM Plex everywhere else — including production. Verified against kit
      // tfw1cme on 2026-09-16. (`Malila` needs no alias: family matching is
      // case-insensitive, so it already matches the kit's `malila`.)
      display: '"Malila", "IBM Plex Sans Thai", sans-serif',
      ui:      '"Aktiv Grotesk Thai", "aktiv-grotesk-thai", "IBM Plex Sans Thai", sans-serif',
      prose:   '"Google Sans", "IBM Plex Sans Thai Looped", serif',
      /** @deprecated Figma renamed `font-family/sans` → `font-family/ui` (2026-08-31). Use `ui`. */
      sans:    '"Aktiv Grotesk Thai", "aktiv-grotesk-thai", "IBM Plex Sans Thai", sans-serif',
      /** @deprecated Figma renamed `font-family/serif` → `font-family/prose` (2026-08-31). Use `prose`. */
      serif:   '"Google Sans", "IBM Plex Sans Thai Looped", serif',
    },
  },
  backOffice: {
    interactive: radius['12'],
    inputSm:     radius['8'],
    inputMd:     radius['12'],
    containerSm: radius['8'],
    containerMd: radius['12'],
    fontFamily: {
      // Malila is also an Adobe Fonts typeface — same fallback note as above.
      display: '"Malila", "IBM Plex Sans Thai", sans-serif',
      ui:      '"IBM Plex Sans Thai", sans-serif',
      prose:   '"IBM Plex Sans Thai Looped", serif',
      /** @deprecated Figma renamed `font-family/sans` → `font-family/ui` (2026-08-31). Use `ui`. */
      sans:    '"IBM Plex Sans Thai", sans-serif',
      /** @deprecated Figma renamed `font-family/serif` → `font-family/prose` (2026-08-31). Use `prose`. */
      serif:   '"IBM Plex Sans Thai Looped", serif',
    },
  },
} as const;

export type ProductStyleName = keyof typeof productStyle;

export const defaultProductStyle: ProductStyleName = 'carivaApp';

export const typography = {
  fontFamily: productStyle[defaultProductStyle].fontFamily,
  // Desktop mode of the Figma "Typography" collection. Verified against live
  // Figma variables 2026-09-07.
  fontSize: {
    display:  { large: 60, medium: 48, small: 36 },
    heading:  { large: 24, medium: 20, small: 16 },
    body:     { large: 16, medium: 14, small: 12 },
    prose:    { large: 16, medium: 14, small: 12 },
    label:    { large: 16, medium: 14, small: 12, xsmall: 10 },
    caption:  { caption: 12 },
  },
  lineHeight: {
    display:  { large: 72, medium: 56, small: 48 },
    heading:  { large: 32, medium: 28, small: 24 },
    body:     { large: 24, medium: 22, small: 18 },
    prose:    { large: 24, medium: 22, small: 18 },
    label:    { large: 24, medium: 20, small: 16, xsmall: 16 },
    caption:  { caption: 16 },
  },
  fontWeight: {
    regular:   400,
    medium:    500,
    semibold:  600,
    bold:      700,
  },
} as const;

export type CarivaColors  = typeof colors;
export type CarivaSpacing = typeof spacing;
